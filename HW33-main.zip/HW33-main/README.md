Just running this whole thing.

Test Django app made to learn this beautiful world of programming.
![image](https://github.com/Skyshmallow/HW33/assets/41758454/36d179da-0cd4-43c9-af2f-1b6563c17b10)
